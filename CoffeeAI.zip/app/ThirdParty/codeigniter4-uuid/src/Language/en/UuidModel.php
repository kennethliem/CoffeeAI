<?php

return [
    // Exceptions
    'incorrectUuidVersion'       => 'The "{0}" is incorrect UUID version.',
    'incorrectValueInUuidFields' => 'The primary key "{0}"" should not be in the "uuidFields" list if you are not using the auto-increment feature.',
];
</main>

<!-- Core -->
<script src="<?= base_url('admin_assets/vendor/@popperjs/core/dist/umd/popper.min.js'); ?>"></script>
<script src="<?= base_url('admin_assets/vendor/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>

<!-- Smooth scroll -->
<script src="<?= base_url('admin_assets/vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js'); ?>"></script>

<!-- Volt JS -->
<script src="<?= base_url('admin_assets/assets/js/volt.js'); ?>"></script>


</body>

</html>